insert into customer VALUES ("U1234",654789,"chetan","B","chavhannavar",123456789,"cbchetan@19",8722654879,"M",13,"maruti galli","belgaum",591247,"1999-5-5","teacher");
insert into customer VALUES ("U1245",654790,"venu","K","patil",897894230,"venu@19",9876542545,"M",27,"ganesh galli","mysore",570024,"2000-2-26","tailor");
insert into customer VALUES ("U1246",654791,"chetan","B","chavhannavar",123456789,"cbchetan@19",8722654879,"M",13,"maruti galli","belgaum",591247,"1999-5-5","teacher");
insert into customer VALUES ("U1247",654792,"deepika","K","padukone",8974500123,"deepika@20",9457860032,"F",58,"sutta galli","bangalore",988951,"1965-02-25","actress");

INSERT into savings_acc VALUES(50000,2,"2012-5-12",654790,"SBI5004");
INSERT into savings_acc VALUES(50000,2,"2012-5-12",654789,"SBI5004");
INSERT into savings_acc VALUES(50000,2,"2012-5-12",654791,"SBI5004");

INSERT into current_acc VALUES(100000,"2016-04-18",654792,"SBI1234",2);
INSERT into current_acc VALUES(20000,"2015-11-13",654790,"SBI1245",2);
INSERT into current_acc VALUES(850000,"2012-08-27",654789,"SBI1678",2);

insert into branch values("SBI1234","banashankari","khanapur");
insert into branch values("SBI4567","Mellahalli","Mysore");
insert into branch values("SBI1245","Nazarabad","Nazarabad");
insert into branch values("SBI1678","K R Mohalla","Double road");
insert into branch values("SBI0986","Chamaraja rd","Banashankari");
insert into branch values("SBI0987","Kollahalli","Bhanupura");
insert into branch values("SBI0967","Masthigudi","Kollapura");

insert into e_services VALUES(001,12345678,78945612,'Y','N');
insert into e_services VALUES(002,65478932,78945612,'N','N');
insert into e_services VALUES(003,45689731,78945612,'Y','Y');

insert into uses_e_services VALUES(654789,1,"2018-04-12");
insert into uses_e_services VALUES(654790,3,"2019-08-01");
insert into uses_e_services VALUES(654792,2,"2018-11-05");

insert into fixed_dep values(200000,5.0,350000,"2019-04-25",654789,"2015-12-27","DEP001","SBI0986");
insert into fixed_dep values(450000,5.0,800000,"2020-02-17",654790,"2016-02-06","DEP002","SBI0986");
insert into fixed_dep values(500000,5.0,1000000,"2019-7-22",654792,"2015-08-15","DEP003","SBI0986");

INSERT into recurr_dep VALUES(250000,20500,4.5,654790,"SBI0987","2019-02-21","RDEP001");
INSERT into recurr_dep VALUES(85000,5000,4.5,654789,"SBI0986","2018-02-17","RDEP002");
INSERT into recurr_dep VALUES(175000,6500,4.5,654792,"SBI1245","2019-06-29","RDEP003");

insert into loan VALUES("L001",300000,7.5,"House loan","2019-04-19","ELIGIBLE",880,"CAR OWNED",654789,"SBI0986");
insert into loan VALUES("L002",50000,7.5,"Bike loan","2019-03-10","ELIGIBLE",880,"Land OWNED",654792,"SBI0986");
insert into loan VALUES("L003",300000,7.5,"Gold loan","2019-07-09","NOT ELIGIBLE",230,"Vehicle OWNED",654790,"SBI0986");

insert into online_locker values(654789,400,'M',"2018-03-15","SBI0986");
insert into online_locker values(654792,400,'M',"2017-12-02","SBI0986");
insert into online_locker values(654790,400,'M',"2017-09-17","SBI0986");


