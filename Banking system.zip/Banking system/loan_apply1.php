<?php 
	$k=$_POST['acc_n'];

	$db=mysqli_connect("localhost","buser","p@ssword") or die(mysqli_connect_error());
	 mysqli_select_db($db,"bank_db") or die(mysqli_error($db));
	 
	 $loan_id='L01';

	 $loan_id=rand(1000,9999);
	$loan_amt=$_POST['loan_amt'];
	$loan_interest=6;
	$loan_purpose=$_POST['loan_purpose'];
	$borrow_date=$_POST['borrow_date'];
	$income_details=$_POST['income_details'];
	$cibil_score=$_POST['cibil_score'];
	$property_details=$_POST['property_details'];
	$acc_no=$_POST['acc_n'];
	$IFSC=$_POST['IFSC_code'];
	$q1=$db->query("SELECT acc_no from customer where acc_no='$acc_no'");
	 $q2=$db->query("SELECT * from savings_acc where acc_no='$acc_no'");
	 $q3=$db->query("SELECT * from current_acc where acc_no='$acc_no'");
	 $q10=$db->query("SELECT * from credit where acc_no='$acc_no'");

	 $r1=mysqli_fetch_array($q2);
	 $r2=mysqli_fetch_array($q3);

	 	if($r1){
	
	 		$q3=$db->query("UPDATE savings_acc set sav_balance=sav_balance+'$_POST[loan_amt]' where acc_no='$acc_no' ");
	 		$r4=$r1['IFSC_code'];
	 	}
	 	else if($r2){
	 
			$q3=$db->query("UPDATE current_acc set curr_bal=curr_bal+'$_POST[loan_amt]' where acc_no='$acc_no'");
			$r4=$r2['IFSC_code'];
	 	}
	// $q4="INSERT INTO loan values('1023',$__POST[loan_amt],$__POST[loan_interest],'$__POST[loan_purpose]','$__POST[borrow_date]','$__POST[income_details]',$__POST[cibil_score],'$__POST[property_details]',$k,'$r4'";

	 //$db->query($q4);

	 $new="INSERT INTO loan VALUES('$loan_id','$loan_amt','$loan_interest','$loan_purpose','$borrow_date','$income_details','$cibil_score','$property_details','$acc_no','$IFSC')";
	 $n='Amount credit through debit amount is ';
	 $a=$k;
	 $n=$n.$a;
	 $d=date("Y-m-d");
	 $new1="INSERT INTO credit(credit_desc,credit_date,acc_no) VALUES('$n','$d','$a')";
	 $db->query($new1);
			// echo $a."</br>";
			//$d=strtime0('now');
			
		if($db->query($new)===TRUE){
			echo "<h1 style='color:red;margin-left:50px'>Successfully Created</br></h1>";
				echo "<a href='userpage.php'><button style='background:green;padding:8px;color:white;margin-left:50px;width:300px;margin-top:100px'> Go to your home page</button></a>";
		}
		else{
			echo "errror";
		}

 ?>

