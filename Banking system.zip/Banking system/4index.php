<?php
//including the database connection file
include_once("config.php");
 
//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
$result = mysqli_query($db, "SELECT * FROM customer "); // using mysqli_query instead
?>
 
<html>
<head>    
    <title>Homepage</title>
    <link rel="stylesheet" href="table.css" type="text/css" media="all">
</head>
 
<body style="background-color: rgba(71, 143, 139, 0.877);">
    <!-- <a href="sign_up.php">Add New Data</a><br/><br/> -->
 
    <table width='80%' border=0>
        <caption><h1>Bank Customers</h1></caption>
        <tr bgcolor='#CCCCCC'>
            <td>FName</td>
            <td>MName</td>
            <td>LName</td>
            <td>Account_NO</td>
            <td>Aadhar_No</td>
            <td>Email</td>
            <td>Mob_No</td>
            <td>Gender</td>
            <td>Address</td> 
            <td>Pincode</td>
            <td>DOB</td>
            <td>Occupation</td>
            <td>Update</td>
        </tr>
        <?php 
        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
        while($res = mysqli_fetch_array($result)) {         
            echo "<tr>";
            echo "<td>".$res['fname']."</td>";
            echo "<td>".$res['minit']."</td>";
            echo "<td>".$res['lname']."</td>";
            echo "<td>".$res['acc_no']."</td>";
            echo "<td>".$res['aadhar_no']."</td>";
            echo "<td>".$res['email_id']."</td>";
            echo "<td>".$res['mob_no']."</td>";
            echo "<td>".$res['gender']."</td>";
            echo "<td>".$res['house_no'].", ".$res['street']."</br>".$res['city']."</td>";
            echo "<td>".$res['pin_code']."</td>";
            echo "<td>".$res['DOB']."</td>";
            echo "<td>".$res['occupation']."</td>";
            echo "<td><a href=\"5edit.php?id=$res[acc_no]\">Edit</a> | <a href=\"6delete.php?id=$res[acc_no]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";        
        }
        ?>
    </table>
    <a href="homepage.html">Home page</a>
    <!-- <a href="debit.html">pay</a> -->
</body>
</html>
