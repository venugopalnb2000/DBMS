<?php 
	$db=mysqli_connect("localhost","buser","p@ssword") or die(mysqli_connect_error());
 	mysqli_select_db($db,"bank_db") or die(mysqli_error($db));
	$ta=$_POST['acc_no'];
	$am=$_POST['am'];
	$ac=$_COOKIE['acc'];
	$am=(int)$am;
	$q1="SELECT sav_balance from savings_acc where acc_no='$ac'";
	$q2="SELECT curr_bal from current_acc where acc_no='$ac'";
	$r1=$db->query($q1);
	$r2=$db->query($q2);
	if($r3=mysqli_fetch_array($r1)){
		$am2=$r3['sav_balance'];
		if($am2<$am){
			echo "Insufficient balance";
		}
		else{
			$q3="UPDATE savings_acc set sav_balance=sav_balance-$am where acc_no='$ac' and sav_balance-$am > 500";
			$ex="SELECT acc_no from savings_acc where acc_no='$ta'";
			$ex1="SELECT acc_no from current_acc where acc_no='$ta'";
			$ex2=$db->query($ex);
			$ex3=$db->query($ex1);
			if($r3=mysqli_fetch_array($ex2)){
				$q5=$db->query("UPDATE savings_acc set sav_balance=sav_balance+$am where acc_no='$ta'");
			}
			else if($r3=mysqli_fetch_array($ex3)){
				$q5=$db->query("UPDATE current_acc set curr_bal=curr_bal+$am where acc_no='$ta'");
			}
			else{
				echo "<p style='color: blue'>SOME OTHER BANK</p>";
			}
			$fa=$db->query("SELECT fname from customer where acc_no='$ta'");
			$fa2=$db->query("SELECT fname from customer where acc_no='$ac'");
			$fan=mysqli_fetch_array($fa);
			$fan2=mysqli_fetch_array($fa2);
			$fna=$fan['fname'];
			$fna2=$fan2['fname'];
			$db->query($q3) or die(mysqli_error($db));
			// echo "<p style='color:red'>Transfered SUCCESSFULLY</p>";
			echo "<h1 style='color:red;margin-left:50px'>TRANSACTION SUCCESSFUL</br></h1>";

			$a=$r3['acc_no'];
			// echo $a."</br>";
			//$d=strtime0('now');
			$d=date("Y-m-d");
			// echo $d."</br>";
			$ran=rand(0,100000);
			// echo $ran."</br>";
			$deta='SENT to  Account Number '.$ta." debitted amount ".$am;
			// echo $deta."</br>";//.$d.$ran;
			$deta1='RECIEVED from  Account Number '.$ac.' creditted amount '.$am;
			// echo $deta1."</br>";
			// echo $ac;
			//print_r($d);
			$de=$db->query("INSERT INTO debit(debit_desc,debit_date,debit_place,acc_no) values('$deta','$d','Bangalore',$ac)") or die (mysqli_error($db));
			$qu=$db->query("INSERT INTO credit (credit_desc,credit_date,acc_no) values('$deta1','$d',$ta)") or die (mysqli_error($db));
			// 
			echo "<a href='userpage.php'><button style='background:green;padding:8px;color:white;margin-left:50px;width:300px;margin-top:100px'> Go to your home page</button></a>";
		}
	}
	else if($r3=mysqli_fetch_array($r2)){
		$am2=$r3['curr_bal'];
		if($am2<$am){
			echo "Insufficient balance";
		}
		else{
			$q3="UPDATE current_acc set curr_bal=curr_bal-$am where acc_no='$ac' and curr_bal-$am > 500";
			$ex="SELECT acc_no from savings_acc where acc_no='$ta'";
			$ex1="SELECT acc_no from current_acc where acc_no='$ta'";
			$ex2=$db->query($ex);
			$ex3=$db->query($ex1);
			if($r3=mysqli_fetch_array($ex2)){
				$q5=$db->query("UPDATE savings_acc set sav_balance=sav_balance+$am where acc_no='$ta'");
			}
			else if($r3=mysqli_fetch_array($ex3)){
				$q5=$db->query("UPDATE current_acc set curr_bal=curr_bal+$am where acc_no='$ta'");
			}
			else{
				echo "SOME OTHER BANK";
			}
			$db->query($q3) or die(mysqli_error($db));
			// echo "<p style='color:red'>SUCCESSFUL</p>";
			// echo "<p  style='color:purple'><a href='userpage.php'> GO to Your page </a></p>";
			echo "<h1 style='color:red;margin-left:50px'>TRANSACTION SUCCESSFUL</br></h1>";
		 	echo "<a href='userpage.php'><button style='background:green;padding:8px;color:white;margin-left:50px;width:300px;margin-top:100px'> Go to your home page</button></a>";
		}
	}
	else{
		echo "<p style='color:red'>TRANSACTION UNSUCCESSFUL</p>";
	}

 ?>