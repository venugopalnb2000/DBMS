<!-- <!DOCTYPE html>
<html>
<head>
	<title>Userpage</title>
</head>
<body>
	<tr>
		<td><a href='pay.php'><button>Pay</button></a></td>
		<td><a href='balance.php'><button>Balance</button></a></td>
		<td><a href='trans.php'><button>CheckTransaction</button></a></td>
		<td><a href='loan_apply.php'><button>Apply_loan</button></a></td>
	</tr>
	<?php 
		if (isset($_COOKIE['userid'])){
			// echo $_COOKIE['userid'];
		}
	 ?>
</body>
</html> -->



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body {
	background-color:rgba(71, 143, 139, 0.877)ba;
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #111;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #eee;
  color: black;
}

.topnav a.active {
  background-color: #383ab5;
  color: white;
}
</style>

<!--Slideshow Style starts-->
<style>
* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
</style>
<!--Slideshow Style Ends-->


</head>
<body style="background-color: rgba(71, 143, 139, 0.877);">

<div class="topnav">
  <a class="active" href="userpage.php">HOME</a>
  <a href="pay.php">Transfer Money</a>
  <a href="balance.php">Balance</a>
  <a href="trans.php">Your Transacions</a>
  <a href="loan_apply.php">Apply Loan</a>
  <a href="locker.html">Locker</a>

  <a href="logout.php">LOGOUT</a>

</div>

<?php 
		if (isset($_COOKIE['userid'])){
			// echo $_COOKIE['userid'];
		}
?>

<div style="padding-left:16px">
  <h2></h2>
  <p></p>
</div>


<h2 style="text-align:center">Hindustan Bank</h2>


<!-- Slideshow body starts-->

<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="banner1.jpg" style="width:100%">
  <div class="text">Caption Text</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="banner4.jpg" style="width:100%">
  <div class="text">Caption Two</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="banner3.jpg" style="width:100%">
  <div class="text">Caption Three</div>
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>
<!-- Slideshow body ends-->


</body>
</html>





