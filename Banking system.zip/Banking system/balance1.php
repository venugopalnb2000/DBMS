<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="table.css" type="text/css" media="all">
</head>
<body style="background-color:rgba(71, 143, 139, 0.877)">
	<h1>User details</h1></br>
	<?php 
		$db=mysqli_connect("localhost","buser","p@ssword") or die(mysqli_connect_error());
		 mysqli_select_db($db,"bank_db") or die(mysqli_error($db));
		 
		$o=$_POST['opt'];
		$q1="SELECT * from customer where acc_no='$o'";
		$r1=$db->query($q1);
		$r2=mysqli_fetch_array($r1);
		$acc=$r2['acc_no'];
		$q2=$db->query("SELECT * from savings_acc where acc_no='$o'");
		$q3=$db->query("SELECT * from current_acc where acc_no='$o'");
		$rp=mysqli_fetch_array($q2);
		$rq=mysqli_fetch_array($q3);
		if($rp>0){
			$tp="savings_acc";
			$ba=$rp['sav_balance'];

		}
		else if($rq>0){
			$tp="current_acc";
			$ba=$rq['curr_bal'];

		}
	 ?>
	 <table>
	 <tr>
	 	<th>NAME</th>
	 	<th>TYPE OF ACCOUNT</th>
	 	<th>ACCOUNT NUMBER</th>
	 	<th>BALANCE</th>
	 </tr>
	 <tr>
	 	<td><?php  echo $r2['fname']." ".$r2['minit']." ".$r2['lname'];?></td>
	 	<td><?php  echo $tp;?></td>
	 	<td><?php echo $o; ?></td>
	 	<td><?php  echo $ba;?></td>
	 </tr>
	</table>
	<!-- <p style='color: blue'><a href="transaction.php">CLICK HERE</a>TO SEE TRANSACTION DETAILS</p> -->
	<?php
	echo "</br><a href=\"transaction.php?id=$o\">CLICK HERE</a> SEE TRANSACTION DETAILS</br>";   
	echo "<a href='userpage.php'>GO TO YOUR PAGE</a>"     
     ?>
</body>
</html>