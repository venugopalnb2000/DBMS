<?php
include_once("config.php");
$result = mysqli_query($db, "SELECT * FROM customer ");
?>
 
 <?php 
	$db=mysqli_connect("localhost","buser","p@ssword") or die(mysqli_connect_error());
	 mysqli_select_db($db,"bank_db") or die(mysqli_error($db));
	 
	$k= $_COOKIE['userid'];
	$q1=$db->query("SELECT acc_no from customer where acc_no in (SELECT acc_no from client where client.user_id='$k')");
	$q2=$db->query("SELECT fname,minit,lname,email_id,mob_no from customer where acc_no in (SELECT acc_no from client where user_id='$k') ");
	while($res = mysqli_fetch_array($q2))
	{
		$fname = $res['fname'];
		$mname = $res['minit'];
		$lname =$res['lname'];
		$email=$res['email_id'];
		$mob_no=$res['mob_no'];
	}

?>





<html>
<head>    
    <title>Homepage</title>
    <link rel="stylesheet" href="table.css" type="text/css" media="all">
</head>
 
<body style="background-color: rgba(71, 143, 139, 0.877);">
    <!-- <a href="sign_up.php">Add New Data</a><br/><br/> -->
 
    <table width='80%' border=0>
        <caption><h1>Bank Customers</h1></caption>
        <tr bgcolor='#CCCCCC'>
            <td>FName</td>
            <td>MName</td>
            <td>LName</td>
            <td>Account_NO</td>
            <td>Aadhar_No</td>
            <td>Email</td>
            <td>Mob_No</td>
            <td>Gender</td>
            <td>Address</td> 
            <td>Pincode</td>
            <td>DOB</td>
            <td>Occupation</td>
            <td>Update</td>
        </tr>
        <?php 
        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
        while($res = mysqli_fetch_array($result)) { 
        }

        ?>
</body>
</html>
