<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body >
	<?php
		$db=mysqli_connect("localhost","buser","p@ssword") or die(mysqli_connect_error());
		mysqli_select_db($db,"bank_db") or die(mysqli_error($db));

		$acc_no=$_GET['acc_no'];
		$locker_size=$_GET['locker_size'];
		if($locker_size=='S'){
			$locker_amt=200;}
		if($locker_size=='M'){
			$locker_amt=400;}
		else{$locker_amt=800;}

		
		$request_date=$_GET['request_date'];
		$IFSC=$_GET['IFSC_code'];

		// $db=mysqli_connect("localhost:3306","root","","final");
		// if(!$db){
		// 	echo "error";
		// }
		$exist=$db->query("SELECT * FROM online_locker WHERE acc_no='$acc_no'");
		
		$new="INSERT INTO online_locker VALUES('$acc_no','$locker_amt','$locker_size','$request_date','$IFSC')";

		if($db->query($new)===TRUE){
			echo "<h1 style='color:red;margin-left:50px'>Successfully Created</br></h1>";
				echo "<a href='userpage.php'><button style='background:green;padding:8px;color:white;margin-left:50px;width:300px;margin-top:100px'> Go to your home page</button></a>";
		}
		else{
			echo "errror";
		}
			

	?>
</body>
</html>