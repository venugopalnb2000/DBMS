<?php
// including the database connection file
include_once("config.php");
 
if(isset($_POST['update']))
{    
    $id = $_POST['id'];
    
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname =$_POST['lname'];
    $email=$_POST['email'];
    $mob_no=$_POST['mob_no'];    
       
        //updating the table
        $result = mysqli_query($db, "UPDATE customer SET fname='$fname',minit='$mname',lname='$lname',email_id='$email',mob_no='$mob_no' WHERE acc_no=$id");
        
        //redirectig to the display page. In our case, it is index.php
        header("Location: 4index.php");
    }
?>
<?php
//getting id from url
$id = $_GET['id'];
 
//selecting data associated with this particular id
$result = mysqli_query($db, "SELECT * FROM customer WHERE acc_no=$id");
 
while($res = mysqli_fetch_array($result))
{
    $fname = $res['fname'];
    $mname = $res['minit'];
    $lname =$res['lname'];
    $email=$res['email_id'];
    $mob_no=$res['mob_no'];
}
?>
<html>
<head>    
    <title>Edit Data</title>
    <link rel="stylesheet" href="form.css" type="text/css" media="all">
</head>
 
<body style="background-color: rgba(71, 143, 139, 0.877);">
    <div>
    <form name="form1" method="post" action="5edit.php">
            <h1>Edit Info</h1>
                <label>FName</label>
                <input type="text" name="fname" value="<?php echo $fname;?>" required>
             
                <label>MName</label>
                <input type="text" name="mname" value="<?php echo $mname;?>" required>
            
                <label>LName</label>
                <input type="text" name="lname" value="<?php echo $lname;?>" required>
            
                <label>Email</label>
                <input type="email" name="email" value="<?php echo $email;?>" required>
             
                <label>Mob_no</label>
                <input type="text" name="mob_no" value="<?php echo $mob_no;?>" required>
            
                <input type="hidden" name="id" value=<?php echo $_GET['id'];?>>
                <input type="submit" name="update" value="Update">
            
    </form>
</div>
</body>
</html>
