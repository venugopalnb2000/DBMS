

<?php 
	$db=mysqli_connect("localhost","buser","p@ssword") or die(mysqli_connect_error());
	 mysqli_select_db($db,"bank_db") or die(mysqli_error($db));
	 
	$k= $_COOKIE['userid'];
	$q1=$db->query("SELECT acc_no from customer where acc_no in (SELECT acc_no from client where client.user_id='$k')");
	$q2=$db->query("SELECT fname,minit,lname,email_id,mob_no from customer where acc_no in (SELECT acc_no from client where user_id='$k') ");
	while($res = mysqli_fetch_array($q2))
	{
		$fname = $res['fname'];
		$mname = $res['minit'];
		$lname =$res['lname'];
		$email=$res['email_id'];
		$mob_no=$res['mob_no'];
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Loan Application</title>
    <link rel="stylesheet" href="form.css" type="text/css" media="all">
</head>
<body style="background-color:rgba(71, 143, 139, 0.877)">
<div>
		<form action ="loan_apply1.php" method="post">
            <h1>Apply Loan</h1>
			<label>Name</label>
				<input type="text" name="Name" value="<?php echo $fname." ".$mname." ".$lname;?>" readonly></label>
		
				<label>Email</label>
			<input type="text" name="email" value="<?php echo $email;?>" readonly>
		
			<label>Mob_no</label>
			<input type="text" name="mob_no" value="<?php echo $mob_no;?> " readonly >
		
			<!-- <label >Loan Amount</label> -->
			<input type="text" placeholder="Enter your Amount" name="loan_amt" required>
			
			<!-- <label >Loan Interest</label> -->
			
			<!-- <label >Loan Purpose</label> --
			
			<!-- <label >Loan Purpose</label> -->
			<input type="text" placeholder="Enter your Loan Purpose" name="loan_purpose" required>
			
			<!-- <label >Borrow Date</label> -->
			<input type="text" placeholder="Enter your Borrow Date" name="borrow_date" required>
			
			<!-- <label >Income Details</label> -->
			<input type="text" placeholder="Enter your Income Details" name="income_details" required>
			
			
			<!-- <label >Cibil Score</label> -->
			<input type="text" placeholder="Enter your Cibil score" name="cibil_score" required>
			
			<!-- <label >Property Details</label> -->
			<input type="text" placeholder="Enter your Property Details" name="property_details" required>
	
			<label>Select the Account to take loan</label>
			<select name='acc_n'>
				<?php 
					while($r1=mysqli_fetch_array($q1)){
						$o=$r1['acc_no'];
						echo "<option value=$o>$o</option>";
					}
					?>
			</select>
		
			<!-- <label >IFSC Code</label> -->
			<input type="text" placeholder="Enter your IFSC Code" name="IFSC_code" required>
            <input type="submit" name="submit">
			
		</form>
	</div>
	 
</body>
</html>