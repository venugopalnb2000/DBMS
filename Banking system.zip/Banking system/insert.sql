insert into loan values ('AA1234', 100000, 4.40, 'HOME LOAN', '2002-02-22', 'Eligible', 880, 'Vehicle owned', 641784537, 'SBI2201' );
insert into loan values ('AB1231', 200000, 4.45, 'VEHICLE LOAN', '2003-03-23', 'Eligible', 830, 'Home owned', 541484527, 'SBI3321' );
insert into loan values ('AC1453', 250000, 4.47, 'HOME LOAN', '2004-04-15', 'Eligible', 780, 'Hotel owned', 441780535, 'SBI2201' );
insert into loan values ('BC1234', 1500000, 5.40, 'HOME LOAN', '2007-07-28', 'Eligible', 980, 'Vehicle owned', 254178453, 'SBI5201' );
insert into loan values ('FD1234', 150000, 3.40, 'FARMER LOAN', '2008-04-14', 'Not Eligible', 880, 'Land owned', 342786537, 'SBI7801' );
insert into loan values ('AA1254', 300000, 7.40, 'HOME LOAN', '2010-05-21', 'Eligible', 880, 'Vehicle owned', 834784537, 'SBI2201' );
insert into loan values ('AD3467', 250000, 7.12, 'HOME LOAN', '2011-04-24', 'Eligible', 678, 'Vehicle owned', 748516482, 'SBI3321' );


insert into branch values ('SBI2201','Jaynagar 4th Block', 'Jaynagar' );
insert into branch values ('SBI3321','Basavangudi 2nd phase', 'Basavangudi' );
insert into branch values ('SBI5201','Off Bannerghatta road', 'Kammanahalli' );
insert into branch values ('SBI7801','Near Sheshadripuram Police Station', 'Gandhinagar' );


insert into savings_acc values (10000, 2.0,'2000-01-01', 641784537, 'SBI2201'   );
insert into savings_acc values (20000, 2.0,'2001-01-01', 541484527, 'SBI3321'   );
insert into savings_acc values (25000, 2.0,'2002-01-11', 441780535, 'SBI2201'   );
insert into savings_acc values (35000, 2.0,'2004-02-14', 254178453, 'SBI5201'   );
insert into savings_acc values (45000, 2.0,'2005-02-14', 342786537, 'SBI7801'   );
insert into savings_acc values (55000, 2.0,'2006-02-24', 834784537, 'SBI2201'   );
insert into savings_acc values (65000, 2.0,'2007-03-25', 748516482, 'SBI3321'   );



insert into current_acc values (250000,'2004-06-25', 159516482, 'SBI3321' );
insert into current_acc values (350000,'2000-06-25', 137784537, 'SBI2201' );
insert into current_acc values (450000,'1999-06-25', 174584537, 'SBI5201' );
insert into current_acc values (550000,'1998-06-25', 120794537, 'SBI7801' );
insert into current_acc values (650000,'1997-06-25', 169794537, 'SBI3321' );


insert into client values ( 641784537,'Venu','Gopal','B',123456789753, 'iamvenu@pes.edu', 9108073724, 'M', '56', 'rajajinagar',
 'Mysore', 562231,'1999-02-02','student','');
insert into client values ( 541484527, 'Chetan','C', 'Chav', 158264789236,'iamchetan@harvard.edu', 7854925147, 'M','78','slum',
'Mumbai', 600124, '2000-02-02', 'student', ''  );
insert into client values ( 441780535, 'Prajwal', 'R', 'P', 124566, 'prajwalpothalkar@gmail.com', 9449528398, 'M', '89', ''   );
insert into client values ();
insert into client values ();







