<!Doctype HTML>
<html>
<head>
<link rel="stylesheet" href="table.css" type="text/css" media="all">
<link rel="stylesheet" href="form.css" type="text/css" media="all">
</head>
<body style="background-color:rgba(71, 143, 139, 0.877)">
<div>
<form action='balance1.php' method="post" style="color: red">
<?php
	$db=mysqli_connect("localhost","buser","p@ssword") or die(mysqli_connect_error());
 	mysqli_select_db($db,"bank_db") or die(mysqli_error($db)); 
	if (isset($_COOKIE['userid'])){
		
		$k= $_COOKIE['userid'];
		$q1="SELECT acc_no  from client where user_id='$k' group by acc_no";
		$r=$db->query($q1);
		$q2="SELECT s.acc_no from client as c , savings_acc as s where user_id='$k' and c.acc_no=s.acc_no ";
		$q3="SELECT s.acc_no from client as c , current_acc as s where user_id='$k' and c.acc_no=s.acc_no ";

		$q8=$db->query("SELECT s.acc_no from client as c , savings_acc as s where user_id='$k' and c.acc_no=s.acc_no");
		$q9=$db->query("SELECT s.acc_no from client as c , current_acc as s where user_id='$k' and c.acc_no=s.acc_no ");
		$r2=$db->query($q2);
		$r3=$db->query($q3);
		echo "<p style='color: blue'>Select the account </br></p>";
		$r10=mysqli_fetch_array($q8);

		echo "<table>";
		echo "<tr><th>Account Type</th><th>Acc no.</th></tr>";


		if($r10>0){
			echo "<tr><td><p style='color: purple'>Savings_acc</p></td>";
		}
		while($r1=mysqli_fetch_array($r2)){
			$o=$r1['acc_no'];
			
			echo '<td><input type="radio" value='.$o.' name="opt" >'.$o.'</td>';
		}
		echo "</tr>";
		$r5=mysqli_fetch_array($q9);
		if($r5>0){
			echo "<tr><td><p style='color: purple'>CURRENT_acc</p></td>";
		}
		while($rk=mysqli_fetch_array($r3)){
			$o=$rk['acc_no'];
			
			echo '<td><input type="radio" value='.$o.' name="opt"  >'.$o.'</td>';
		}
		echo "</tr>";
		echo "</table></br></br>";
	}

 ?>
 <input type="submit" name="SUBMIT">
</form>
</div>
</body>
</html>