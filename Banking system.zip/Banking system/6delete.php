<?php
include("config.php");
 
//getting id of the data from url
$id = $_GET['id'];
 
//deleting the row from table
$result = mysqli_query($db, "DELETE FROM customer WHERE acc_no=$id");
 
//redirecting to the display page (index.php in our case)
header("Location:4index.php");
?>
