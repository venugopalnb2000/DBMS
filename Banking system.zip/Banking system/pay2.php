<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="form.css" type="text/css" media="all">
</head>
<body style="background-color: rgba(71, 143, 139, 0.877);">
	<?php 
	$p=$_POST['opt'];
	$na='acc';
	setcookie($na,$p);
	//echo $p;
 ?>
 <div>
 <form action="pay3.php" method="post">
	 <h1>Transfer Money</h1>
 	<input type="text" name="acc_no" placeholder="Target Acc_no">
 	<input type="text" name="am" placeholder="Enter amount">
 	<input type="submit" name="submit">
 </form>
</div>	
</body>
</html>