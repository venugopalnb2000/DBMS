<?php 
	$db=mysqli_connect("localhost","buser","p@ssword") or die(mysqli_connect_error());
 	mysqli_select_db($db,"bank_db") or die(mysqli_error($db));
 	$ui=$_POST['uid'];
 	$acc=$_POST['acc_no'];
 	$ci=$_POST['cid'];
 	$pa=$_POST['pwd'];
 	$ch="SELECT * from customer where acc_no='$acc' and cust_id='$ci'";
 	$lo="SELECT * from client where  acc_no='$acc'";
  	$ch1=$db->query($ch);
  	$ch2=$db->query($lo);
 	$ro=mysqli_fetch_array($ch2,MYSQLI_NUM);
 	if($ro>0){
		//  echo "Account already Exists. Login"."</br>"."<a href='login.html'>Login here</a>";
		 echo"<h1 style='color:red;margin-left:50px'>Account already Exists.</br></h1>";
    	 echo"<a href='login.html'><button style='background:green;padding:8px;color:white;margin-left:50px;width:300px;margin-top:100px'> Go to Login page</button></a>";
 	}
 	else{
 		$r=mysqli_fetch_array($ch1,MYSQLI_NUM);
 		if($r>0){
 			$r1=mysqli_fetch_array($ch1,MYSQLI_ASSOC);
 			$in="INSERT into client values ('$acc','$ui','$pa')";
 			$db->query($in);
 			echo "<font color='green'><b>SUCCESSFULLY SIGNED IN </b></br></br>"."Go to Main page "."<a href='login.html'>Go HERE</a>";
 		}
 		else
 			echo "Check your account number again ";
 }

 ?>