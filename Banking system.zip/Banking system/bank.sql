--client is customer and user_log is client
drop database bank_db;
create database bank_db;
connect bank_db;
create table customer(	
					cust_id varchar(30) unique, 
					acc_no  BIGINT unique ,
					fname varchar(15), 
					minit varchar(4), 
					lname varchar(15),  
					aadhar_no BIGINT, 
					email_id varchar(50), 
					mob_no BIGINT, 
					gender char(1), 
					house_no BIGINT, 
					street varchar(50), 
					city varchar(15), 
					pin_code BIGINT, 
					DOB date, 
					occupation varchar(15),  
					primary key(acc_no,cust_id)
						
);
--create table user_log( user_id varchar(10),acc_no bigint unique references client(acc_no),psswd varchar(20),primary key (user_id,acc_no) )


create table client(
					acc_no  BIGINT unique ,
					user_id varchar(10)  , 
					psswd varchar(10),
					primary key(acc_no,user_id)
					  );

					
create table e_services (	service_id BIGINT primary key, 
							atm_card_no BIGINT, 
							pan_no BIGINT, 
							sms_alert char(1), 
							update_aadhar char(1)	);


create table uses_e_services (	    acc_no BIGINT unique references client(acc_no),
									service_id BIGINT , 
									apply_date date,
									FOREIGN KEY (service_id) REFERENCES e_services(service_id),
									PRIMARY KEY (service_id,acc_no) );



create table branch (	IFSC_code varchar(18) primary key, 
						branch_addr varchar(30), 
						branch_name varchar(15)  );


create table online_locker(	acc_no BIGINT references client(acc_no), 
							locker_amt BIGINT, 
							locker_size char(1), 
							request_date date, 
							IFSC_code varchar(15) references branch(IFSC_code) );


create table credit (	credit_id int(30) auto_increment,credit_desc varchar(100),credit_date date, acc_no BIGINT references client(acc_no),primary key(credit_id)  );


create table debit (  debit_id int(30) auto_increment,debit_desc varchar(100),debit_date date,debit_place varchar(10),acc_no BIGINT references client(acc_no) , primary key(debit_id) )auto_increment=100000;



create table loan (	loan_id varchar(10) primary key, 
					loan_amt BIGINT, 
					loan_BIGINTrest float, 
					loan_purpose varchar(15), 
					borrow_date date, 
					income_details varchar(18), 
					cibil_score BIGINT, 
					property_details varchar(20), 
					acc_no BIGINT references client(acc_no), 
					IFSC_code varchar(15) references branch(IFSC_code)  );


create table savings_acc (	sav_balance BIGINT, 
							sav_int_rate float, 
							acc_created_date date, 
							acc_no BIGINT  references client(acc_no) , 
							IFSC_code varchar(15) references branch(IFSC_code));


create table current_acc (	curr_bal BIGINT, 
							acc_created_date date, 
							acc_no BIGINT  references client(acc_no), 
							IFSC_code varchar(18) references branch(IFSC_code) ,
							curr_rate float);


create table fixed_dep (	dep_amt BIGINT, 
							FD_int_rate float, 
							mat_amt BIGINT,
							maturity_date date, 
							acc_no BIGINT  references client(acc_no), 
							dep_date date, 
							dep_id varchar(30), 
							IFSC_code varchar(18) references branch(IFSC_code));


create table recurr_dep (	amount BIGINT, 
							monthly_dep float, 
							RD_int_rate float, 
							acc_no BIGINT  references client(acc_no), 
							IFSC_code varchar(18) references branch(IFSC_code), 
							dep_date date, 
							dep_id varchar(30) );





