<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
    <h1 style='color:red;margin-left:50px'>You are Logged out</br></h1>
    <a href='homepage.html'><button style='background:green;padding:8px;color:white;margin-left:50px;width:300px;margin-top:100px'> Go to your home page</button></a>
</body>
</html>