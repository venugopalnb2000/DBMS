<?php 
	$db=mysqli_connect("localhost","buser","p@ssword") or die(mysqli_connect_error());
 	mysqli_select_db($db,"bank_db") or die(mysqli_error($db));
 	$ui=$_POST['uid'];
 	$pa=$_POST['pwd'];
 	$lo="SELECT * from client where user_id='$ui' and psswd='$pa'";
	if($ui==='admin' && $pa='admin123'){
		echo "<a href='4index.php'><button style='background:green;padding:8px;color:white;margin-left:50px;width:300px;margin-top:100px'> Go to ADMIN</button></a>";

	}
	else{
 	$ch2=$db->query($lo);
 	$ro=mysqli_fetch_array($ch2,MYSQLI_NUM);
 	$r1=mysqli_num_rows($ch2);
 	// $r1=mysqli_fetch_object($ch2,MYSQLI_ASSOC);
 	//$r1=mysqli_fetch_object($ch2);
 	$acc=$ro[0];
 	//echo $acc;
 	if($r1==0){
 		echo "<font color='green'></br>USERNAME OR PASSWORD IS INCORRECT</br></br>"."<a href='login.html'>GO BACK</a> ";
 	}
 	else{
 		$cn='userid';
 		setcookie($cn,$ui);
 		// $k=$ro;$i=0;
 		// while($k>=0){
 		// 	echo "<form><input type='radio' name='option' value=$acc>$acc</form>";
 		// 	$k=$k-1;
 		// }
		//  echo "Go to your page "."<a href='userpage.php'>Go here</a>";
		 echo "<h1 style='color:red;margin-left:50px'>Successfully Logged In</br></h1>";
		 echo "<a href='userpage.php'><button style='background:green;padding:8px;color:white;margin-left:50px;width:300px;margin-top:100px'> Go to your home page</button></a>";
	 }
}

 ?>