
<?php 
	$db=mysqli_connect("localhost","buser","p@ssword") or die(mysqli_connect_error());
	mysqli_select_db($db,"bank_db") or die(mysqli_error($db)); 
	$q2=$db->query("SELECT * from branch");
		
?>
<!Doctype HTML>
<html>
<head>
<link rel="stylesheet" href="table.css" type="text/css" media="all">
</head>
<body style="background-color: rgba(71, 143, 139, 0.877);">
	<?php
		echo "<table>";
		echo "<tr><th>IFSC_CODE</th><th>BRANCH_ADDRESS</th><th>BRANCH_NAME</th></tr>";
		while($row = mysqli_fetch_row($q2))
		{
			echo "<tr>";
			foreach($row as $cell)
				echo "<td>$cell</td>";
			echo "</tr>\n";
		}
		echo "</table></br></br>";
		echo "<a href='homepage.html'>GO BACK</a>";
	?>
</body>
</html>
