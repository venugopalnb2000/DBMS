

<?php
    $db=mysqli_connect("localhost","buser","p@ssword") or die(mysqli_connect_error());
    mysqli_select_db($db,"bank_db");
?>