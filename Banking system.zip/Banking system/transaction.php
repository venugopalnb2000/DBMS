<?php 
	$acc=$_GET['id'];
	$acc+(int)$acc;
	echo "<p style='fontsize:3px ;color:#fff'>ACCOUNT NUMBER   </br></br> $acc</p>";

	$db=mysqli_connect("localhost","buser","p@ssword") or die(mysqli_connect_error());
	 mysqli_select_db($db,"bank_db");
	 
 	$q1=$db->query("SELECT credit_id,credit_date from credit where acc_no=$acc");
	$q2=$db->query("SELECT credit_id,credit_desc,credit_date from credit where acc_no=$acc union ( SELECT debit_id,debit_desc,debit_date from debit where acc_no=$acc) order by credit_date");
	 
 	
 ?>

<!Doctype HTML>
<html>
<head>
<link rel="stylesheet" href="table.css" type="text/css" media="all">
</head>
<body style="background-color:rgba(71, 143, 139, 0.877)">
	<?php
		echo "<table>";
		echo "<tr><th>Transaction_id</th><th>Description</th><th>Date</th></tr>";
		while($row = mysqli_fetch_row($q2))
	    {
		   echo "<tr>";
		   foreach($row as $cell)
			   echo "<td>$cell</td>";
		    echo "</tr>\n";
	    }
		echo "</table>";
		echo "</br></br>";
	    echo "<a href=\"debit.php?id=$acc\"><button >DEBIT_DETAILS</button></a>";
		echo "<a href=\"credit.php?id=$acc\"><button >CREDIT_DETAILS</button></a></br>";
		echo "</br></br>";
	    echo "<a href='userpage.php'>GO TO YOUR PAGE</a>"
	?>
</body>
</html>
