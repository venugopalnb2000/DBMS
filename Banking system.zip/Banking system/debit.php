<?php
$db=mysqli_connect("localhost","buser","p@ssword") or die(mysqli_connect_error());
 	mysqli_select_db($db,"bank_db") or die(mysqli_error($db));
 	$ac=$_GET['id'];
 	$q2=$db->query("SELECT * from debit where acc_no=$ac");
 	
?>
	 
<!Doctype HTML>
<html>
<head>
<link rel="stylesheet" href="table.css" type="text/css" media="all">
</head>
<body style="background-color:rgba(71, 143, 139, 0.877)">
	<?php
		echo "<table>";
		echo "<tr><th>DEBIT_ID</th><th>DESCRIPTION</th><th>DATE</th><th>PLACE</th></tr>";
		while($row = mysqli_fetch_array($q2))
	    {
		   echo "<tr>";
		   $cell=$row['debit_id'];
		   echo "<td>$cell</td>";
		   echo "<td>$row[debit_desc]</td>";
		   echo "<td>$row[debit_date]</td>";
		   echo "<td>$row[debit_place]</td>";
		   
		   echo "</tr>\n";
		}
		echo "</table></br>";
		
	    echo "<a href='userpage.php'>GO BACK</a>";
	?>
</body>
</html>