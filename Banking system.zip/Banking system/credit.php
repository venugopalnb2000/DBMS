<?php
$db=mysqli_connect("localhost","buser","p@ssword") or die(mysqli_connect_error());
 	mysqli_select_db($db,"bank_db") or die(mysqli_error($db));
 	$ac=$_GET['id'];
 	$q2=$db->query("SELECT * from credit where acc_no=$ac");
 	
?>

<!Doctype HTML>
<html>
<head>
<link rel="stylesheet" href="table.css" type="text/css" media="all">
</head>
<body style="background-color:rgba(71, 143, 139, 0.877)">
	<?php
		echo "<table>";
		echo "<tr><th>CREDIT_ID</th><th>DESCRIPTION</th><th>DATE</th></tr>";
		while($row = mysqli_fetch_array($q2))
	    {
		   echo "<tr>";
		   $cell=$row['credit_id'];
   
		   echo "<td>$cell</td>";
		   echo "<td>$row[credit_desc]</td>";
		   echo "<td>$row[credit_date]</td>";
		   echo "</tr>\n";
	    }
	    echo "</table></br>";
	    echo "<a href='userpage.php'>GO BACK</a>";
	?>
</body>
</html>